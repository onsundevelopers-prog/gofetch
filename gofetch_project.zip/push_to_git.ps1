# Check if git is installed
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "Error: Git is not installed or not in your PATH." -ForegroundColor Red
    Write-Host "Please install Git from https://git-scm.com/downloads" -ForegroundColor Yellow
    Write-Host "After installing, please RESTART your terminal or IDE and run this script again." -ForegroundColor Yellow
    exit 1
}

# Ensure we are in the right directory
$projectPath = "c:\Users\Ose\Downloads\go-fetch (2)\go-fetch (1)"
Set-Location -Path $projectPath

# Initialize git repository if not present
if (-not (Test-Path ".git")) {
    Write-Host "Initializing new git repository..."
    git init
    git branch -M main
}

# Check remote configuration
$targetRemote = "https://github.com/onsundevelopers-prog/gofetch.git"
$currentRemote = git remote get-url origin 2>$null

if (-not $currentRemote) {
    Write-Host "Adding remote origin..."
    git remote add origin $targetRemote
} elseif ($currentRemote -ne $targetRemote) {
    Write-Host "Updating remote origin URL..."
    git remote set-url origin $targetRemote
}

# Add all files
Write-Host "Staging files..."
git add .

# Check git status
$status = git status --porcelain
if ($status) {
    Write-Host "Committing changes..."
    git commit -m "Initial commit / Update from agent"
} else {
    Write-Host "No changes to commit."
}

# Push
Write-Host "Pushing to remote... You may be asked for credentials."
try {
    git push -u origin main
    Write-Host "Successfully pushed to $targetRemote" -ForegroundColor Green
} catch {
    Write-Host "Failed to push. Please check your credentials or internet connection." -ForegroundColor Red
    Write-Host $_
}
